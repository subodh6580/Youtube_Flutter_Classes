import 'package:flutter/material.dart';
import 'package:my_first_app/app.dart';

void main() {
  runApp(const MyFirstApp());
}
